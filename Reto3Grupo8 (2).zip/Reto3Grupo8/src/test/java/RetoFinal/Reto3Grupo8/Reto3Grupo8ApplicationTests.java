package RetoFinal.Reto3Grupo8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3Grupo8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
