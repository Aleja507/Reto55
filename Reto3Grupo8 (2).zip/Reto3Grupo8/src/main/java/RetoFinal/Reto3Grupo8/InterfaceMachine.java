
package RetoFinal.Reto3Grupo8;

import org.springframework.data.repository.CrudRepository;

public interface InterfaceMachine extends CrudRepository<Machine, Integer> {
    
}
